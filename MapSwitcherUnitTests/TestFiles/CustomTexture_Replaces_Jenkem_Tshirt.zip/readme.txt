Copy both files to :

C:\[Path To SessionGame]\Content\Customization\Characters\AMXX\UpperBody\Brands\Jenkem\Textures